async function main() {
  let pyodide = await loadPyodide();
  let pythoncode= await (await fetch("test.py")).text()
  await pyodide.loadPackage("pandas")
  // Pyodide is now ready to use...
  console.log(pyodide.runPython(pythoncode));
};
main();