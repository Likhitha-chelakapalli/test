import sys
import pandas as pd
sys.version
d={"col1":[1,2],"col2":[3,4]}
df=pd.DataFrame(d)
print(df)